# birthday-invite
Welcome to my HTML Birthday Invitation project! This repository showcases a simple yet functional birthday invitation created using HTML. The invitation includes key event details and incorporates a location map link to provide easy navigation to the event venue.


